package com.jd.inttest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InttestApplication {

	public static void main(String[] args) {
		SpringApplication.run(InttestApplication.class, args);
	}

}
