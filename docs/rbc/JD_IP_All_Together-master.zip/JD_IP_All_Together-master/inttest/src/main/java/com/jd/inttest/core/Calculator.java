package com.jd.inttest.core;

import java.util.function.Function;


public interface Calculator  {
    int apply(int a, int b);
}
