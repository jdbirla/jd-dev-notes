package com.jd.inttest.core;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;


/**
 * Created by jd birla on 04-05-2023 at 08:07
 */


public class Test {
    public static void main(String[] args) {


    }


}


