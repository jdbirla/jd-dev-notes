# IBM Test
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/175e4238-50b0-4a1d-9f47-aad85bb021f1)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/f395715d-093f-437a-80b7-e462370777dc)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/c040ba3d-dd0c-4345-bc6b-514de015fc8e)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/787dc5b6-5a5a-4310-b9c3-f3e792c195e2)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/a51a5549-4093-4564-b511-d7a607596bc6)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/f6a16177-a94b-415c-9b0c-d0ca29c0702a)
## Angular
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/231fe94e-8440-4591-be6b-f2fd9bb8bde6)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/908b06fb-cba1-4979-8452-c4c4dbe5f888)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/ae703cf6-6885-4ab0-9f14-c9fde07a0316)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/dc0a11d3-f6bb-4ea5-9bc3-23e147846f3e)
'ng configuration'
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/35d2af64-3579-43ff-a59b-79017398284a)
`@input('userData') users: any[] = [];`
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/7b56873f-305f-48c0-9788-b42d760884ff)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/d1d1774e-2a59-427e-9495-86d28cb14b3b)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/4cd91189-dc47-4a1f-93e9-2c532fdd0d8a)
`ngviewStart` is not hook
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/7932d82d-46dd-4af1-a76c-f691abdc001d)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/d8e585ff-66a5-4878-a868-d0ad8f2b38ac)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/f53218d2-2158-4b2f-8a14-99f896dfc35a)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/b72499fd-b3fc-485b-92e3-305dc6c0879c)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/0bbba9ae-72bd-4721-ba00-cd96f658cbec)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/bcc1e894-49ae-4da2-a3de-53b050786c24)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/c27f99bb-71f5-4048-9247-20bcb2de281f)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/9b0417f3-0dd1-4ed5-bceb-31087ed9bf5b)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/cbf8efd5-0b0a-4b94-afb1-cf2649629278)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/ff7c0a91-32f0-423f-aa15-7c89839c24a9)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/5d237679-ea89-4535-82da-3ae58a48bd18)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/0c89b53e-d5d6-4372-a6e1-31872c149952)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/0cb4ab55-6548-4036-905a-e7a3e7ebab2e)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/da615d9f-591a-4918-b1e3-a8972e5c09f2)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/f85f22b6-a33e-437f-a3f5-bfd6bfead22b)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/4066573f-02a1-43c2-9a46-d7f93c978ca8)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/30970f04-4e50-4544-997f-41838d269889)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/57d65100-16bf-43cd-b94c-f9a1b6419657)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/70cad3a2-b873-4cf8-ae68-b98362ac7bff)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/0329fd29-8a8b-4ea1-846f-c4ceddb8dd31)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/c9c5ef54-9c3e-46fe-8428-1bd46e58ddaf)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/f9490607-6927-40d9-8b41-b643d5ab00ea)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/3ca13380-586d-4a82-a900-6da8b901944f)
![image](https://github.com/jdbirla/JD_IP_All_Together/assets/69948118/040ebd7d-dade-43f5-b7a8-0920a7434e30)
















