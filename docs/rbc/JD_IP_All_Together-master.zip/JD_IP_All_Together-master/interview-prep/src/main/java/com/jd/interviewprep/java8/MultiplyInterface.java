package com.jd.interviewprep.java8;

/**
 * Created by jd birla on 02-02-2023 at 13:39
 */
public interface MultiplyInterface {
    public int multiply(int a, int b);
}
