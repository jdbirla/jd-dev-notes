package com.jd.interviewprep.designpattern.prototype;

public class Membership {

}
