package com.jd.interviewprep.multithreading.jankov.memory.model;

/**
 * Created by jd birla on 11-07-2023 at 15:56
 */
public class MyObject {
}
