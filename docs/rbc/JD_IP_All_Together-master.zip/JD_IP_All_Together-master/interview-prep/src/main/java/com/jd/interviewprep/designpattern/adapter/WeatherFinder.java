package com.jd.interviewprep.designpattern.adapter;

public interface WeatherFinder {

	int find(String city);

}
