package com.jd.interviewprep.designpattern.factory;

public interface Pizza {

	void prepare();

	void bake();

	void cut();

}
