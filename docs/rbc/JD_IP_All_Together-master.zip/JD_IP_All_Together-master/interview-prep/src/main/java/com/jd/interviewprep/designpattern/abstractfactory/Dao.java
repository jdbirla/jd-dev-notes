package com.jd.interviewprep.designpattern.abstractfactory;

public interface Dao {

	void save();
}
