package com.jd.interviewprep.designpattern.observer;

public interface Observer {
	 public void update(String location);
}
