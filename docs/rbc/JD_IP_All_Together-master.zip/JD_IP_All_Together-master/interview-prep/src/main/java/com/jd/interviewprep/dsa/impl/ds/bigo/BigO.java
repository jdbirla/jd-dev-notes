package com.jd.interviewprep.dsa.impl.ds.bigo;

public class BigO {
    public static void main(String[] args) {
        printItem(10);
    }

    public static void printItem(int n)
    {
        for (int i = 0; i < n; i++) {
            System.out.println(i);
        }
    }
}
