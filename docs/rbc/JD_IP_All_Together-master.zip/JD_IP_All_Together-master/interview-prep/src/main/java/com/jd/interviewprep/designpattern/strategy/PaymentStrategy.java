package com.jd.interviewprep.designpattern.strategy;

public interface PaymentStrategy {
	void pay(double amount);
}
