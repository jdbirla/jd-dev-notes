package com.jd.interviewprep.multithreading.jankov.creating.threads;

/**
 * Created by jd birla on 11-07-2023 at 14:47
 */
public class ThreadExample {
    public static void main(String[] args) {
        Thread thread = new Thread();
        thread.start();
    }


}
