package com.jd.interviewprep.multithreading.jankov.memory.model;

/**
 * Created by jd birla on 11-07-2023 at 16:04
 */
public class PassingObject {
}
