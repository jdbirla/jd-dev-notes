package com.jd.interviewprep.designpattern.factory;

public class Test {

	public static void main(String[] args) {

		PizzaStore ps = new PizzaStore();
		ps.orderPizza("veggie");

	}

}
