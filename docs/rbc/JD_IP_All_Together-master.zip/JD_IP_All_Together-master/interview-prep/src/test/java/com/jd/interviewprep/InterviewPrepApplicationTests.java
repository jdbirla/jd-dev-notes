package com.jd.interviewprep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterviewPrepApplicationTests {

	@Test
	void contextLoads() {
	}

}
