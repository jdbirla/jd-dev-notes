package com.jd.test.Test;

/**
 * Created by jd birla on 11-06-2023 at 06:21
 */

@FunctionalInterface
public interface JdStringValidation {
     Integer val(String a);
}
